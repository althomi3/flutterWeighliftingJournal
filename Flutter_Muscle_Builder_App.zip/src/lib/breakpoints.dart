class Breakpoints {
  static const breakpoint_s = 600;
  static const breakpoint_m = 768;
}